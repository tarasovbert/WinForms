﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestWF2
{
    public  class SubjectInfo
    {
        public string Name { get; set; }
        public int DaysCount { get; set; }

        //public override string ToString()
        //{
        //    return String.Format($"{Name} - {DaysCount}");
        //}

    }
}
